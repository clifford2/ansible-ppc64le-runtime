# Ansible Collection - azul.inventory

This collection contains an inventory plugin for EYE.
